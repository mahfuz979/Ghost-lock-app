package com.ghostlock.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

private data class AppItem(val pkg: String, val label: String)

class AppsActivity : Activity() {

    private val items = ArrayList<AppItem>()
    private val selected = HashSet<String>()
    private lateinit var adapter: AppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        selected.addAll(Prefs.protectedApps(this))

        val launcherIntent = Intent(Intent.ACTION_MAIN)
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val found = pm.queryIntentActivities(launcherIntent, 0)
        val list = found
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        items.addAll(list)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val title = TextView(this)
        title.text = "যে অ্যাপগুলো লক করতে চান সেগুলোতে টিক দিন"
        title.textSize = 16f
        title.setPadding(dp(16), dp(16), dp(16), dp(12))
        root.addView(title)

        val lv = ListView(this)
        adapter = AppAdapter()
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, position, _ ->
            val pkg = items[position].pkg
            if (selected.contains(pkg)) selected.remove(pkg) else selected.add(pkg)
            Prefs.setProtectedApps(this, selected)
            adapter.notifyDataSetChanged()
        }
        root.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (!Gate.ok(this)) finish()
    }

    override fun onPause() {
        super.onPause()
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 60_000L
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        private fun buildRow(): LinearLayout {
            val row = LinearLayout(this@AppsActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(8), dp(16), dp(8))

            val icon = ImageView(this@AppsActivity)
            row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))

            val name = TextView(this@AppsActivity)
            name.textSize = 16f
            val nlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            nlp.leftMargin = dp(12)
            row.addView(name, nlp)

            val check = CheckBox(this@AppsActivity)
            check.isClickable = false
            check.isFocusable = false
            row.addView(check)
            return row
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: buildRow()
            val icon = row.getChildAt(0) as ImageView
            val name = row.getChildAt(1) as TextView
            val check = row.getChildAt(2) as CheckBox
            val item = items[position]
            name.text = item.label
            check.isChecked = selected.contains(item.pkg)
            try {
                icon.setImageDrawable(packageManager.getApplicationIcon(item.pkg))
            } catch (e: Exception) {
                icon.setImageDrawable(null)
            }
            return row
        }
    }
}
