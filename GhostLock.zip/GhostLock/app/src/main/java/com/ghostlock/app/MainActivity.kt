package com.ghostlock.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private companion object {
        const val REQ_PICK = 1001
    }

    private lateinit var statusView: TextView
    private var picking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))

        val title = TextView(this)
        title.text = "GhostLock"
        title.textSize = 28f
        root.addView(title)

        statusView = TextView(this)
        statusView.textSize = 15f
        statusView.setPadding(0, dp(12), 0, dp(12))
        root.addView(statusView)

        addButton(root, "১. লক স্ক্রিনের ছবি বাছাই করুন") { pickPhoto() }
        addButton(root, "২. গোপন ট্যাপ এলাকা সেট করুন") {
            if (Prefs.hasPhoto(this)) {
                startActivity(Intent(this, SecretAreaActivity::class.java))
            } else {
                toast("আগে ছবি বাছাই করুন")
            }
        }
        addButton(root, "৩. সুরক্ষিত অ্যাপ বাছাই করুন") {
            startActivity(Intent(this, AppsActivity::class.java))
        }
        addButton(root, "৪. অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val note = TextView(this)
        note.setTextColor(Color.DKGRAY)
        note.textSize = 13f
        note.setPadding(0, dp(20), 0, 0)
        note.text = "সীমাবদ্ধতা: এটি ফোর্স-স্টপ, আনইনস্টল, সেফ মোড বা সিস্টেম-লেভেলের সব বাইপাস আটকাতে পারে না। " +
            "অ্যাক্সেসিবিলিটি সার্ভিস বন্ধ করলে লক কাজ করবে না। গোপন এলাকা ভুলে গেলে সেটিংসে ঢোকা যাবে না, তখন অ্যাপটি আনইনস্টল করতে হবে।"
        root.addView(note)

        val scroll = ScrollView(this)
        scroll.addView(
            root,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(10)
        parent.addView(b, lp)
    }

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        picking = true
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 5 * 60 * 1000L
        try {
            startActivityForResult(Intent.createChooser(i, "ছবি বাছাই করুন"), REQ_PICK)
        } catch (e: Exception) {
            picking = false
            toast("ছবি বাছাই করার অ্যাপ পাওয়া যায়নি")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        picking = false
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 3 * 60 * 1000L
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val appCtx = applicationContext
        Thread {
            val ok = Prefs.importPhoto(appCtx, uri)
            runOnUiThread {
                if (ok) {
                    toast("ছবি সেভ হয়েছে। এবার গোপন এলাকা সেট করুন")
                    startActivity(Intent(this, SecretAreaActivity::class.java))
                } else {
                    toast("ছবি লোড করা যায়নি")
                }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (!Gate.ok(this)) {
            finish()
            return
        }
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        if (!picking) {
            Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 60_000L
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, GhostLockService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun refreshStatus() {
        val yes = "✔"
        val no = "✘"
        statusView.text =
            "ছবি: ${if (Prefs.hasPhoto(this)) yes else no}\n" +
                "গোপন এলাকা: ${if (Prefs.hasSecret(this)) yes else no}\n" +
                "সুরক্ষিত অ্যাপ: ${Prefs.protectedApps(this).size} টি\n" +
                "অ্যাক্সেসিবিলিটি সার্ভিস: ${if (isServiceEnabled()) "চালু $yes" else "বন্ধ $no"}"
    }
}
