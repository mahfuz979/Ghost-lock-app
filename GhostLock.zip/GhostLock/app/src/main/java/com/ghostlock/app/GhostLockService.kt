package com.ghostlock.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Only watches which app window came to the front. Reads no screen content.
 */
class GhostLockService : AccessibilityService() {

    private var imePackages: Set<String> = emptySet()
    private var lastLaunchPkg: String? = null
    private var lastLaunchAt: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        refreshImePackages()
    }

    private fun refreshImePackages() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imePackages = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) {
            // keep previous value
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        if (pkg == packageName) return
        if (pkg == "com.android.systemui") return
        if (imePackages.contains(pkg)) return
        if (!Prefs.isConfigured(this)) return

        if (Prefs.protectedApps(this).contains(pkg)) {
            if (Prefs.unlockedPackage == pkg) return

            val cur = LockActivity.current
            if (cur != null && !cur.isFinishing) return

            val now = SystemClock.elapsedRealtime()
            if (pkg == lastLaunchPkg && now - lastLaunchAt < 800) return
            lastLaunchPkg = pkg
            lastLaunchAt = now

            val i = Intent(this, LockActivity::class.java)
            i.putExtra(LockActivity.EXTRA_PKG, pkg)
            i.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
            startActivity(i)
        } else {
            // User moved to some other (non-protected) app: protected apps lock again.
            Prefs.unlockedPackage = null
        }
    }

    override fun onInterrupt() {}
}
