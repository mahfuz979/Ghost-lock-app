package com.ghostlock.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.ViewGroup
import kotlin.math.hypot

/**
 * Full-screen photo. No text, no PIN field. Unlock = tap the secret area.
 */
class LockActivity : Activity() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val EXTRA_SETTINGS = "settings"

        @Volatile
        var current: LockActivity? = null
    }

    private lateinit var photoView: PhotoTapView
    private var targetPkg: String? = null
    private var settingsMode = false
    private var unlocked = false
    private var wrongTaps = 0
    private var lockedOutUntil = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        secureWindow()
        goImmersive()

        targetPkg = intent.getStringExtra(EXTRA_PKG)
        settingsMode = intent.getBooleanExtra(EXTRA_SETTINGS, false)

        val bmp = Prefs.loadBitmap(this)
        if (bmp == null || !Prefs.hasSecret(this)) {
            finish()
            return
        }

        current = this
        photoView = PhotoTapView(this)
        photoView.bitmap = bmp
        photoView.onTap = { x, y -> handleTap(x, y) }
        setContentView(
            photoView,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    private fun handleTap(fx: Float, fy: Float) {
        val now = SystemClock.elapsedRealtime()
        if (now < lockedOutUntil) return

        val w = photoView.width.toFloat()
        val h = photoView.height.toFloat()
        val dx = (fx - Prefs.secretX(this)) * w
        val dy = (fy - Prefs.secretY(this)) * h
        val r = Prefs.secretR(this) * w

        if (hypot(dx, dy) <= r) {
            unlock()
        } else {
            wrongTaps++
            if (wrongTaps >= 5) {
                wrongTaps = 0
                lockedOutUntil = now + 30_000L // silent 30 s pause after 5 wrong taps
            }
        }
    }

    private fun unlock() {
        unlocked = true
        if (settingsMode) {
            Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 3 * 60 * 1000L
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            Prefs.unlockedPackage = targetPkg
        }
        finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (settingsMode) {
            finish()
        } else {
            goHome()
        }
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN)
        home.addCategory(Intent.CATEGORY_HOME)
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(home)
        finish()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }

    override fun onStop() {
        super.onStop()
        if (!unlocked && !isFinishing) finish()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }
}
