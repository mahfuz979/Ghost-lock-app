package com.ghostlock.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

object Prefs {
    private const val FILE = "ghostlock_prefs"
    private const val K_X = "secret_x"
    private const val K_Y = "secret_y"
    private const val K_R = "secret_r"
    private const val K_APPS = "protected_apps"
    private const val PHOTO = "lock_photo.jpg"

    /** Package that was just unlocked (kept in memory only). */
    @Volatile
    var unlockedPackage: String? = null

    /** Time until which settings screens stay open without re-unlocking. */
    @Volatile
    var settingsUnlockedUntil: Long = 0L

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun photoFile(c: Context): File = File(c.filesDir, PHOTO)
    fun hasPhoto(c: Context): Boolean = photoFile(c).exists()
    fun hasSecret(c: Context): Boolean = sp(c).contains(K_X)
    fun isConfigured(c: Context): Boolean = hasPhoto(c) && hasSecret(c)

    fun secretX(c: Context): Float = sp(c).getFloat(K_X, 0.5f)
    fun secretY(c: Context): Float = sp(c).getFloat(K_Y, 0.5f)
    fun secretR(c: Context): Float = sp(c).getFloat(K_R, 0.08f)

    fun saveSecret(c: Context, x: Float, y: Float, r: Float) {
        sp(c).edit().putFloat(K_X, x).putFloat(K_Y, y).putFloat(K_R, r).apply()
    }

    fun protectedApps(c: Context): Set<String> {
        val s = sp(c).getStringSet(K_APPS, null) ?: return emptySet()
        return HashSet(s)
    }

    fun setProtectedApps(c: Context, apps: Set<String>) {
        sp(c).edit().putStringSet(K_APPS, HashSet(apps)).apply()
    }

    fun loadBitmap(c: Context): Bitmap? {
        val f = photoFile(c)
        if (!f.exists()) return null
        return BitmapFactory.decodeFile(f.absolutePath)
    }

    /** Copies the chosen photo into private app storage (downscaled, rotation fixed). */
    fun importPhoto(c: Context, uri: Uri): Boolean {
        return try {
            val resolver = c.contentResolver

            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
            while (maxSide / sample > 2400) sample *= 2

            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false

            var orientation = ExifInterface.ORIENTATION_NORMAL
            try {
                resolver.openInputStream(uri)?.use {
                    orientation = ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                }
            } catch (e: Exception) {
                // ignore: keep the image as decoded
            }

            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> {
                    m.postRotate(90f)
                    m.postScale(-1f, 1f)
                }
                ExifInterface.ORIENTATION_TRANSVERSE -> {
                    m.postRotate(270f)
                    m.postScale(-1f, 1f)
                }
            }
            val bmp = if (m.isIdentity) decoded else
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)

            val tmp = File(c.filesDir, "tmp_photo.jpg")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            tmp.copyTo(photoFile(c), overwrite = true)
            tmp.delete()
            true
        } catch (t: Throwable) {
            false
        }
    }
}
