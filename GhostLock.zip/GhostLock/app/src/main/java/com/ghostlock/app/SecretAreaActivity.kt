package com.ghostlock.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class SecretAreaActivity : Activity() {

    private lateinit var photoView: PhotoTapView
    private lateinit var bar: LinearLayout
    private var barOnTop = false
    private var radius = 0.08f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        secureWindow()
        goImmersive()

        val bmp = Prefs.loadBitmap(this)
        if (bmp == null) {
            toast("আগে একটি ছবি বাছাই করুন")
            finish()
            return
        }

        val frame = FrameLayout(this)
        photoView = PhotoTapView(this)
        photoView.bitmap = bmp
        if (Prefs.hasSecret(this)) {
            photoView.markerX = Prefs.secretX(this)
            photoView.markerY = Prefs.secretY(this)
            radius = Prefs.secretR(this)
            photoView.showMarker = true
        }
        photoView.markerR = radius
        photoView.onTap = { x, y ->
            photoView.markerX = x
            photoView.markerY = y
            photoView.showMarker = true
            photoView.invalidate()
        }
        frame.addView(
            photoView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setBackgroundColor(Color.argb(200, 0, 0, 0))
        bar.setPadding(dp(16), dp(12), dp(16), dp(12))

        val hint = TextView(this)
        hint.setTextColor(Color.WHITE)
        hint.text = "ছবির যে জায়গায় ট্যাপ করলে খুলবে সেখানে ট্যাপ করুন। বৃত্তের আকার স্লাইডার দিয়ে ঠিক করুন।"
        bar.addView(hint)

        val seek = SeekBar(this)
        seek.max = 17
        seek.progress = ((radius * 100f).toInt() - 3).coerceIn(0, 17)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                radius = (progress + 3) / 100f
                photoView.markerR = radius
                photoView.invalidate()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        bar.addView(seek)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val save = Button(this)
        save.text = "সেভ"
        save.setOnClickListener { save() }
        row.addView(save, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val move = Button(this)
        move.text = "উপর/নিচ"
        move.setOnClickListener { toggleBar() }
        row.addView(move, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val cancel = Button(this)
        cancel.text = "বাতিল"
        cancel.setOnClickListener { finish() }
        row.addView(cancel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        bar.addView(row)

        frame.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
        setContentView(frame)
    }

    private fun toggleBar() {
        barOnTop = !barOnTop
        val lp = bar.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (barOnTop) Gravity.TOP else Gravity.BOTTOM
        bar.layoutParams = lp
    }

    private fun save() {
        if (!photoView.showMarker) {
            toast("আগে ছবিতে একটি জায়গায় ট্যাপ করুন")
            return
        }
        Prefs.saveSecret(this, photoView.markerX, photoView.markerY, radius)
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 3 * 60 * 1000L
        toast("গোপন এলাকা সেভ হয়েছে")
        finish()
    }

    override fun onResume() {
        super.onResume()
        if (!Gate.ok(this)) finish()
    }

    override fun onPause() {
        super.onPause()
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 60_000L
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }
}
