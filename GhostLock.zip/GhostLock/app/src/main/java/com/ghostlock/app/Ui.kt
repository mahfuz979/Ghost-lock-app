package com.ghostlock.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.View
import android.view.WindowManager
import android.widget.Toast

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

@Suppress("DEPRECATION")
fun Activity.goImmersive() {
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    window.decorView.systemUiVisibility = (
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )
}

/** Blocks screenshots and the recents thumbnail of the private photo. */
fun Activity.secureWindow() {
    window.setFlags(
        WindowManager.LayoutParams.FLAG_SECURE,
        WindowManager.LayoutParams.FLAG_SECURE
    )
}

/** Settings screens require the photo-unlock once a lock is configured. */
object Gate {
    fun ok(a: Activity): Boolean {
        if (!Prefs.isConfigured(a)) return true
        if (System.currentTimeMillis() < Prefs.settingsUnlockedUntil) return true
        a.startActivity(
            Intent(a, LockActivity::class.java).putExtra(LockActivity.EXTRA_SETTINGS, true)
        )
        return false
    }
}
